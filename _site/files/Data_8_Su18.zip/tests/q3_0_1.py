test = {
  'name': 'Question 3.0.1',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> # It looks like you've choosen an illegal option (not within 1-5)
          >>> bottom_left >= 1 and bottom_left <= 5
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
