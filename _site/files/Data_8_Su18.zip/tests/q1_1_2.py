test = {
  'name': 'Question 1.1.3',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> unstemmed_run.item(0).startswith('run')
          True
          >>> len(unstemmed_run) > 1
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
